import csv
import tkinter as tk
from tkinter import filedialog, messagebox, ttk


COURSES = (
    "Основы Python",
    "Разработка приложений в Tkinter",
    "Веб-разработка",
    "Работа с базами данных",
    "Компьютерная графика",
)

STUDY_FORMATS = (
    "Очное обучение",
    "Дистанционное обучение",
    "Смешанный формат",
)

EXTRAS = (
    "Получение сертификата",
    "Доступ к видеозаписям",
    "Дополнительные практические занятия",
)


class CourseRegistrationApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Регистрация на учебные курсы")
        self.root.geometry("940x760")
        self.root.minsize(650, 500)
        self.root.configure(bg="#f4f7fb")

        self.students = []
        self.entries = {}
        self.extra_vars = {}
        self.course_var = tk.StringVar()
        self.format_var = tk.StringVar()
        self.search_var = tk.StringVar()

        self._build_ui()
        self.search_var.trace_add("write", self._refresh_table)

    def _build_ui(self):
        style = ttk.Style()
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("TFrame", background="#f4f7fb")
        style.configure("TLabelframe", background="#f4f7fb")
        style.configure("TLabelframe.Label", background="#f4f7fb", foreground="#24364b")
        style.configure("TLabel", background="#f4f7fb")
        style.configure("Treeview", rowheight=25)

        main = ttk.Frame(self.root, padding=12)
        main.pack(fill="both", expand=True)
        main.columnconfigure(0, weight=1)
        main.rowconfigure(3, weight=1)

        ttk.Label(
            main,
            text="Регистрация на учебные курсы",
            font=("Segoe UI", 17, "bold"),
            foreground="#173b63",
        ).grid(row=0, column=0, sticky="w", pady=(0, 10))

        student_frame = ttk.LabelFrame(main, text="Данные студента", padding=10)
        student_frame.grid(row=1, column=0, sticky="ew", pady=(0, 9))
        student_frame.columnconfigure(1, weight=1)
        student_frame.columnconfigure(3, weight=1)

        fields = (
            ("Фамилия, имя, отчество:", "full_name", 0, 0),
            ("Возраст:", "age", 0, 2),
            ("Номер телефона:", "phone", 1, 0),
            ("Электронная почта:", "email", 1, 2),
            ("Учебное заведение:", "institution", 2, 0),
        )
        for label, key, row, column in fields:
            ttk.Label(student_frame, text=label).grid(
                row=row, column=column, sticky="w", padx=(0, 6), pady=4
            )
            entry = ttk.Entry(student_frame)
            entry.grid(
                row=row,
                column=column + 1,
                sticky="ew",
                padx=(0, 12 if column == 0 else 0),
                pady=4,
            )
            self.entries[key] = entry
        student_frame.columnconfigure(1, weight=3)
        student_frame.columnconfigure(3, weight=2)

        options_row = ttk.Frame(main)
        options_row.grid(row=2, column=0, sticky="ew", pady=(0, 9))
        options_row.columnconfigure(0, weight=1)
        options_row.columnconfigure(1, weight=1)

        course_frame = ttk.LabelFrame(options_row, text="Курс и форма обучения", padding=10)
        course_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 5))
        ttk.Label(course_frame, text="Учебный курс:").pack(anchor="w")
        self.course_box = ttk.Combobox(
            course_frame,
            textvariable=self.course_var,
            values=COURSES,
            state="readonly",
        )
        self.course_box.pack(fill="x", pady=(3, 8))
        ttk.Label(course_frame, text="Форма обучения:").pack(anchor="w")
        for study_format in STUDY_FORMATS:
            ttk.Radiobutton(
                course_frame,
                text=study_format,
                variable=self.format_var,
                value=study_format,
            ).pack(anchor="w", pady=1)

        extras_frame = ttk.LabelFrame(options_row, text="Дополнительные возможности", padding=10)
        extras_frame.grid(row=0, column=1, sticky="nsew", padx=(5, 0))
        for extra in EXTRAS:
            self.extra_vars[extra] = tk.BooleanVar(value=False)
            ttk.Checkbutton(
                extras_frame,
                text=extra,
                variable=self.extra_vars[extra],
            ).pack(anchor="w", pady=3)

        actions = ttk.Frame(main)
        actions.grid(row=3, column=0, sticky="nsew")
        actions.columnconfigure(0, weight=1)
        actions.rowconfigure(2, weight=1)

        form_buttons = ttk.Frame(actions)
        form_buttons.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        ttk.Button(
            form_buttons, text="Зарегистрироваться", command=self._register_student
        ).pack(side="left", padx=(0, 6))
        ttk.Button(form_buttons, text="Очистить форму", command=self._clear_form).pack(
            side="left"
        )

        search_frame = ttk.Frame(actions)
        search_frame.grid(row=1, column=0, sticky="ew", pady=(0, 5))
        search_frame.columnconfigure(1, weight=1)
        ttk.Label(search_frame, text="Поиск по Ф. И. О. или курсу:").grid(
            row=0, column=0, sticky="w", padx=(0, 7)
        )
        ttk.Entry(search_frame, textvariable=self.search_var).grid(
            row=0, column=1, sticky="ew"
        )

        table_frame = ttk.Frame(actions)
        table_frame.grid(row=2, column=0, sticky="nsew")
        table_frame.columnconfigure(0, weight=1)
        table_frame.rowconfigure(0, weight=1)
        columns = ("full_name", "age", "course", "study_format", "phone")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")
        headings = {
            "full_name": "Ф. И. О.",
            "age": "Возраст",
            "course": "Курс",
            "study_format": "Форма обучения",
            "phone": "Телефон",
        }
        widths = {"full_name": 190, "age": 65, "course": 205, "study_format": 150, "phone": 125}
        for column in columns:
            self.tree.heading(column, text=headings[column])
            self.tree.column(column, width=widths[column], minwidth=55, anchor="w")
        self.tree.grid(row=0, column=0, sticky="nsew")
        y_scroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        y_scroll.grid(row=0, column=1, sticky="ns")
        x_scroll = ttk.Scrollbar(table_frame, orient="horizontal", command=self.tree.xview)
        x_scroll.grid(row=1, column=0, sticky="ew")
        self.tree.configure(yscrollcommand=y_scroll.set, xscrollcommand=x_scroll.set)

        table_buttons = ttk.Frame(actions)
        table_buttons.grid(row=3, column=0, sticky="ew", pady=(8, 0))
        ttk.Button(
            table_buttons, text="Показать подробности", command=self._show_details
        ).pack(side="left", padx=(0, 6))
        ttk.Button(
            table_buttons, text="Удалить выбранную запись", command=self._delete_student
        ).pack(side="left", padx=(0, 6))
        ttk.Button(table_buttons, text="Сохранить в файл", command=self._save_to_file).pack(
            side="left", padx=(0, 6)
        )
        ttk.Button(table_buttons, text="Закрыть программу", command=self.root.destroy).pack(
            side="right"
        )

    def _validate_form(self):
        data = {key: entry.get().strip() for key, entry in self.entries.items()}
        labels = {
            "full_name": "Фамилия, имя и отчество",
            "age": "Возраст",
            "phone": "Номер телефона",
            "email": "Электронная почта",
            "institution": "Учебное заведение",
        }
        for key, label in labels.items():
            if not data[key]:
                messagebox.showerror("Ошибка ввода", f"Заполните поле «{label}».", parent=self.root)
                self.entries[key].focus_set()
                return None

        try:
            age = int(data["age"])
        except ValueError:
            messagebox.showerror("Ошибка ввода", "Возраст должен быть целым числом.", parent=self.root)
            self.entries["age"].focus_set()
            return None
        if not 14 <= age <= 80:
            messagebox.showerror("Ошибка ввода", "Возраст должен быть от 14 до 80 лет.", parent=self.root)
            self.entries["age"].focus_set()
            return None

        email = data["email"]
        if "@" not in email or "." not in email:
            messagebox.showerror(
                "Ошибка ввода",
                "Укажите корректный адрес электронной почты (он должен содержать @ и .).",
                parent=self.root,
            )
            self.entries["email"].focus_set()
            return None

        phone = data["phone"]
        if not phone or any(character not in "0123456789+" for character in phone) or not any(
            character.isdigit() for character in phone
        ):
            messagebox.showerror(
                "Ошибка ввода",
                "Номер телефона может содержать только цифры и символ +.",
                parent=self.root,
            )
            self.entries["phone"].focus_set()
            return None

        if not self.course_var.get():
            messagebox.showerror("Ошибка ввода", "Выберите учебный курс.", parent=self.root)
            self.course_box.focus_set()
            return None
        if not self.format_var.get():
            messagebox.showerror("Ошибка ввода", "Выберите форму обучения.", parent=self.root)
            return None

        return {
            "full_name": data["full_name"],
            "age": age,
            "phone": phone,
            "email": email,
            "institution": data["institution"],
            "course": self.course_var.get(),
            "study_format": self.format_var.get(),
            "extras": [name for name, variable in self.extra_vars.items() if variable.get()],
        }

    def _register_student(self):
        student = self._validate_form()
        if student is None:
            return
        self.students.append(student)
        self._refresh_table()
        extras_text = ", ".join(student["extras"]) if student["extras"] else "не выбраны"
        messagebox.showinfo(
            "Регистрация завершена",
            f"Студент успешно зарегистрирован!\n\n"
            f"Ф. И. О.: {student['full_name']}\n"
            f"Курс: {student['course']}\n"
            f"Форма обучения: {student['study_format']}\n"
            f"Дополнительные возможности: {extras_text}",
            parent=self.root,
        )
        self._clear_form()

    def _clear_form(self):
        for entry in self.entries.values():
            entry.delete(0, tk.END)
        self.course_var.set("")
        self.format_var.set("")
        for variable in self.extra_vars.values():
            variable.set(False)

    def _refresh_table(self, *_):
        query = self.search_var.get().strip().casefold()
        for item in self.tree.get_children():
            self.tree.delete(item)
        for index, student in enumerate(self.students):
            if query and query not in student["full_name"].casefold() and query not in student[
                "course"
            ].casefold():
                continue
            self.tree.insert(
                "",
                "end",
                iid=str(index),
                values=(
                    student["full_name"],
                    student["age"],
                    student["course"],
                    student["study_format"],
                    student["phone"],
                ),
            )

    def _selected_student(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showerror("Нет выбора", "Сначала выберите запись в таблице.", parent=self.root)
            return None, None
        index = int(selection[0])
        return index, self.students[index]

    def _show_details(self):
        _, student = self._selected_student()
        if student is None:
            return
        extras_text = "\n".join(f"• {item}" for item in student["extras"]) or "Не выбраны"
        messagebox.showinfo(
            "Подробности регистрации",
            f"Ф. И. О.: {student['full_name']}\n"
            f"Возраст: {student['age']}\n"
            f"Телефон: {student['phone']}\n"
            f"Электронная почта: {student['email']}\n"
            f"Учебное заведение: {student['institution']}\n"
            f"Курс: {student['course']}\n"
            f"Форма обучения: {student['study_format']}\n"
            f"Дополнительные возможности:\n{extras_text}",
            parent=self.root,
        )

    def _delete_student(self):
        index, student = self._selected_student()
        if student is None:
            return
        if messagebox.askyesno(
            "Подтверждение удаления",
            f"Удалить запись студента «{student['full_name']}»?",
            parent=self.root,
        ):
            self.students.pop(index)
            self._refresh_table()

    def _save_to_file(self):
        if not self.students:
            messagebox.showerror("Нет данных", "Список зарегистрированных студентов пуст.", parent=self.root)
            return
        path = filedialog.asksaveasfilename(
            parent=self.root,
            title="Сохранить список студентов",
            defaultextension=".csv",
            filetypes=(("CSV-файл", "*.csv"), ("Текстовый файл", "*.txt"), ("Все файлы", "*.*")),
        )
        if not path:
            return
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as file:
                writer = csv.writer(file, delimiter=";")
                writer.writerow(
                    ("Ф. И. О.", "Возраст", "Телефон", "Электронная почта", "Курс",
                     "Форма обучения", "Дополнительные возможности")
                )
                for student in self.students:
                    writer.writerow(
                        (
                            student["full_name"],
                            student["age"],
                            student["phone"],
                            student["email"],
                            student["course"],
                            student["study_format"],
                            ", ".join(student["extras"]) if student["extras"] else "Не выбраны",
                        )
                    )
        except OSError as error:
            messagebox.showerror("Ошибка сохранения", f"Не удалось сохранить файл:\n{error}", parent=self.root)
            return
        messagebox.showinfo("Сохранение завершено", f"Данные сохранены в файл:\n{path}", parent=self.root)


def main():
    root = tk.Tk()
    CourseRegistrationApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
